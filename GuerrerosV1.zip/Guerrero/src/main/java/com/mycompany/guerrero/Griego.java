/*
 *@autor Danna Zharick Mendez Chantre
 *@autor Brayan Andres Carrillo Quiñones
 */


package com.mycompany.guerrero;

class Griego extends Guerrero {
    public Griego(String nombre, int edad, int fuerza, String nombreReal) {
        super(nombre, edad, fuerza);
        this.nombre = nombreReal;
    }

    public Griego() {
        super();
    }

    @Override
    public boolean retirarse() {
        return herido && fuerza > 0;
    }
}
