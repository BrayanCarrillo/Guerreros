package com.mycompany.guerrero;

import java.util.ArrayList;
import java.util.Random;

public class Batalla {
    public static void main(String[] args) {
        System.out.println("--------------------Instrucciones------------------");
        System.out.println("1. Ingresa la cantidad de guerreros que participarán en la guerra.");
        System.out.println("2. Ingresa los datos de los líderes de cada bando (Griegos y troyanos).");
        System.out.println("3. El resto de guerreros se generará de forma aleatoria con estadísticas con una fuerza mayor a 5 hasta un total de 10.");
        System.out.println("4. Se mostrará una lista de los guerreros de cada bando.");
        System.out.println("5. Se mostrará cada enfrentamiento, enfrentando de forma aleatoria cada guerrero con el del bando contrario.");
        System.out.println("6. Después de cada enfrentamiento se mostrará el resultado del enfrentamiento.");
        System.out.println("7. Al finalizar todos los enfrentamientos se mostrará el bando ganador y se mostrará el número de bajas, de heridos, heridos retirados, todo por separado para cada equipo.");
        System.out.println("8. Al final se mostrará el número total de bajas y los guerreros que quedaron vivos con el emoji de una corona.");

        // Ingresar la cantidad de guerreros
        int numGuerreros = 20;

        // Generar nombres aleatorios
        ArrayList<String> nombres = generarNombresAleatorios(numGuerreros);

        // Ingresa los datos de los líderes de cada bando aquí
        Guerrero liderTroyano = new Troyano("LiderTroyano", 30, 8, "NombreRealLiderTroyano");
        Guerrero liderGriego = new Griego("LiderGriego", 35, 9, "NombreRealLiderGriego");

        int numSoldados = numGuerreros - 2; // Descontando los líderes
        Guerrero[] troyanos = new Guerrero[numSoldados];
        Guerrero[] griegos = new Guerrero[numSoldados];

        for (int i = 0; i < numSoldados; i++) {
            Random random = new Random();
            int edad = random.nextInt(46) + 15;
            int fuerza = random.nextInt(5) + 6;

            troyanos[i] = new Troyano("Troyano" + (i + 1), edad, fuerza, nombres.remove(0));
            griegos[i] = new Griego("Griego" + (i + 1), edad, fuerza, nombres.remove(0));
        }

        System.out.println("---------------Lista de Guerreros---------------");
        System.out.println("Troyanos:");
        for (Guerrero troyano : troyanos) {
            System.out.println(troyano.getNombre());
        }

        System.out.println("Griegos:");
        for (Guerrero griego : griegos) {
            System.out.println(griego.getNombre());
        }

        int troyanosVivos = numSoldados;
        int griegosVivos = numSoldados;

        for (int i = 0; i < numSoldados; i++) {
            Guerrero troyano = troyanos[i];
            Guerrero griego = griegos[i];

            int ataqueAleatorio = new Random().nextInt(10) + 1;
            int danio = ataqueAleatorio;

            troyano.fuerza -= danio;
            griego.fuerza -= danio;

            String mensajeArma = obtenerMensajeArma();

            String resultadoTroyano = obtenerResultado(troyano);
            String resultadoGriego = obtenerResultado(griego);

            String mensaje = troyano.getNombre() + " atacó a " + griego.getNombre() + ", " + danio + " de daño " +
                    "(" + mensajeArma + ")" + "\n" + griego.getNombre() + " quedó con una fuerza actual de " +
                    griego.getFuerza() + ". Resultado estado actual de " + griego.getNombre() + ": " + resultadoGriego +
                    ". Resultado estado actual de " + troyano.getNombre() + ": " + resultadoTroyano;

            System.out.println(mensaje);
        }

        System.out.println("---------------Resultados de la Batalla---------------");

        String resultado = "Empate";
        if (troyanosVivos > griegosVivos) {
            resultado = "Ganan los troyanos";
        } else if (troyanosVivos < griegosVivos) {
            resultado = "Ganan los griegos";
        }

        int troyanosBajas = numSoldados - troyanosVivos;
        int griegosBajas = numSoldados - griegosVivos;
        int totalBajas = troyanosBajas + griegosBajas;

        System.out.println(resultado);
        System.out.println("Número de bajas troyanos: " + troyanosBajas);
        System.out.println("Número de bajas griegos: " + griegosBajas);
        System.out.println("Total de bajas: " + totalBajas);

        // Mostrar guerreros que quedaron vivos con emoji de corona
        System.out.println("Guerreros que quedaron vivos con corona:");
        for (int i = 0; i < troyanosVivos; i++) {
            System.out.println(troyanos[i].getNombre() + " 👑");
        }
        for (int i = 0; i < griegosVivos; i++) {
            System.out.println(griegos[i].getNombre() + " 👑");
        }
    }

    private static ArrayList<String> generarNombresAleatorios(int numNombres) {
        ArrayList<String> nombres = new ArrayList<>();
        nombres.add("Aquiles");
        nombres.add("Héctor");
        nombres.add("Paris");
        nombres.add("Agamenón");
        nombres.add("Ulises");
        nombres.add("Apolo");
        nombres.add("Afrodita");
        nombres.add("Atenea");
        nombres.add("Zeus");
        nombres.add("Hera");
        nombres.add("Perseo");
        nombres.add("Heracles");
        nombres.add("Prometeo");
        nombres.add("Odiseo");
        nombres.add("Andrómeda");
        nombres.add("Casiopea");
        nombres.add("Perseo");
        nombres.add("Medusa");
        nombres.add("Teseo");
        nombres.add("Ariadna");

        ArrayList<String> nombresAleatorios = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < numNombres; i++) {
            int indice = random.nextInt(nombres.size());
            nombresAleatorios.add(nombres.remove(indice));
        }

        return nombresAleatorios;
    }

    private static String obtenerMensajeArma() {
        String[] mensajesArma = {
            "con una espada afilada",
            "con una lanza",
            "con un hacha brutal",
            "con un escudo mágico",
            "con una flecha certera"
        };
        int indice = new Random().nextInt(mensajesArma.length);
        return mensajesArma[indice];
    }

    private static String obtenerResultado(Guerrero guerrero) {
        if (guerrero.isMuerto()) {
            return "Muerto";
        } else if (guerrero.isHerido() && guerrero.retirarse()) {
            return "Herido/retirado";
        } else if (guerrero.isHerido()) {
            return "Herido";
        } else {
            return "Vivo";
        }
    }
}
