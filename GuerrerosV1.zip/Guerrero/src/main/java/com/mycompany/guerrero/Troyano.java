/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guerrero;

class Troyano extends Guerrero {
    public Troyano(String nombre, int edad, int fuerza, String nombreReal) {
        super(nombre, edad, fuerza);
        this.nombre = nombreReal;
    }

    public Troyano() {
        super();
    }

    @Override
    public boolean retirarse() {
        return false;
    }
}





