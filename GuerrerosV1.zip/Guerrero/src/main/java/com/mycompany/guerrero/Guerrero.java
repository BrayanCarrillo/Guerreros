/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guerrero;

import java.util.Random;

abstract class Guerrero {
    protected String nombre;
    protected int edad;
    protected int fuerza;
    protected boolean herido;
    protected boolean muerto;

    public Guerrero(String nombre, int edad, int fuerza) {
        this.nombre = nombre;
        this.edad = comprobarEdad(edad) ? edad : 25;
        this.fuerza = comprobarFuerza(fuerza) ? fuerza : 5;
        this.herido = false;
        this.muerto = false;
    }

    public Guerrero() {
        this("GuerreroX", 15, 1);
    }

    public Guerrero(Guerrero otro, String nombre) {
        this.nombre = nombre;
        this.edad = otro.edad;
        this.fuerza = otro.fuerza;
        this.herido = otro.herido;
        this.muerto = otro.muerto;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getFuerza() {
        return fuerza;
    }

    public boolean isHerido() {
        return herido;
    }

    public boolean isMuerto() {
        return muerto;
    }

    public abstract boolean retirarse();

    public static boolean comprobarEdad(int edad) {
        return (edad >= 15 && edad <= 60);
    }

    public static boolean comprobarFuerza(int fuerza) {
        return (fuerza >= 1 && fuerza <= 10);
    }
}
