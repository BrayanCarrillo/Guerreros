/*
 *@autor Danna Zharick Mendez Chantre
 *@autor Brayan Andres Carrillo Quiñones
 */


package guerreritos;

class Griego extends Guerrero {
    public Griego(String nombre, int edad, int fuerza) {
        super(nombre, edad, fuerza);
    }

    public Griego() {
        super();
    }

    public Griego(Guerrero otroGuerrero, String nombre) {
        super(otroGuerrero, nombre);
    }

    Griego(Guerrero lider, String obtenerNombreAleatorio, int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Griego(String nombre, String apellido, int edad, int fuerza) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean retirarse() {
        return (this.herido && !this.muerto);
    }
}
