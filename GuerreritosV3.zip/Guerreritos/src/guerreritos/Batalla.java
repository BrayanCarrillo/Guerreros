package guerreritos;

import java.util.*;

public class Batalla {
    private static Set<String> nombresGriegos = new HashSet<>(Arrays.asList(
            "Aquiles", "Héctor", "Odiseo", "Perseo", "Teseo", "Heracles", "Atenea", "Zeus", "Afrodita", "Apolo"));

    private static Set<String> nombresTroyanos = new HashSet<>(Arrays.asList(
            "Paris", "Eneas", "Príamo", "Héleno", "Polidoro", "Casandra", "Elena", "Andrómaca", "Hernesto", "Aeneas"));

    private static Map<String, String> apellidosGuerreros = new HashMap<>();

    private static List<String> mensajesBatalla = Arrays.asList(
            " atacó a ",
            " lanzó su espada contra ",
            " No tuvo piedad contra",
            " desató su furia contra ",
            " arremetió con fuerza contra ");

    private static List<String> mensajesContraataque = Arrays.asList(
            " contratacó a ",
            " bloqueó el ataque de ",
            " esquivó el ataque de ",
            " respondió con un contraataque a ",
            " prepara su contraataque contra ");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Menú con título estilizado
        System.out.println("\u001B[33m \n\t\t\t\t\t\t\u001B[1m\u001B[31m Battle Simulator \u001B[0m\n"); // Amarillo y Rojo

        // Instrucciones en verde
        System.out.println("\u001B[32m-------------------- Instrucciones --------------------\u001B[0m");
        System.out.println("1. El jugador ingresa los datos y estadísticas del líder de cada bando (Griegos y Troyanos).");
        System.out.println("2. El jugador ingresa la cantidad de guerreros el cual sera el mismo para ambos equipos.");
        System.out.println("3. El resto de guerreros se generará de forma aleatoria con estadísticas con una fuerza mayor a 5 hasta un total de 10.");
        System.out.println("4. Se mostrará una lista de los guerreros de cada bando.");
        System.out.println("5. Se mostrará cada enfrentamiento, enfrentando de forma aleatoria cada guerrero con el del bando contrario.");
        System.out.println("6. Después de cada enfrentamiento se mostrará el resultado del enfrentamiento.");
        System.out.println("7. Al finalizar todos los enfrentamientos se mostrará el bando ganador y se mostrará el número de bajas, de heridos, heridos retirados, todo por separado para cada equipo y que al final muestre el número total de bajas y los guerreros que quedaron vivos con su nombre.\u001B[0m");

        // Ingresar datos del líder de cada bando
        Guerrero liderGriego = ingresarLider("Griego");
        Guerrero liderTroyano = ingresarLider("Troyano");

        // Ingresar la cantidad de soldados
        System.out.print("\u001B[34mIngrese el número de soldados para cada equipo: \u001B[0m"); // Azul
        int cantidadSoldados = scanner.nextInt();

        // Validar líder con más de 10 de fuerza y más de 18 años
        while (liderGriego.getFuerza() > 10 || liderGriego.getEdad() < 18 || liderTroyano.getFuerza() > 10 || liderTroyano.getEdad() < 18) {
            System.out.println("\u001B[31mEl líder debe tener más de 10 de fuerza y más de 18 años. Inténtelo de nuevo.\u001B[0m");
            liderGriego = ingresarLider("Griego");
            liderTroyano = ingresarLider("Troyano");
        }

        // Generar ejércitos aleatorios
        List<Griego> ejercitoGriego = generarEjercitoGriego(liderGriego, cantidadSoldados);
        List<Troyano> ejercitoTroyano = generarEjercitoTroyano(liderTroyano, cantidadSoldados);

        // Mostrar lista de guerreros de cada bando
        System.out.println("\u001B[36mEjército Griego:\u001B[0m"); // Cyan
        mostrarEjercito(ejercitoGriego);

        System.out.println("\u001B[36mEjército Troyano:\u001B[0m"); // Cyan
        mostrarEjercito(ejercitoTroyano);

        // Realizar enfrentamientos
        realizarEnfrentamientos(ejercitoGriego, ejercitoTroyano);

        // Mostrar resultados finales
        mostrarResultadosFinales(ejercitoGriego, ejercitoTroyano);
    }

    private static Guerrero ingresarLider(String tipo) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\u001B[32mIngrese los datos del líder " + tipo + ":\u001B[0m"); // Verde
        System.out.print("\u001B[32mNombre:\u001B[0m ");
        String nombre = scanner.nextLine();
        System.out.print("\u001B[32mApellido:\u001B[0m ");
        String apellido = scanner.nextLine();
        System.out.print("\u001B[32mEdad:\u001B[0m ");
        int edad = scanner.nextInt();
        System.out.print("\u001B[32mFuerza:\u001B[0m ");
        int fuerza = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea

        // Validar líder con más de 10 de fuerza y más de 18 años
        while (fuerza > 10 || edad < 18) {
            System.out.println("\u001B[31mEl líder debe tener más de 10 de fuerza y más de 18 años. Inténtelo de nuevo.\u001B[0m");
            System.out.println("\u001B[32mIngrese los datos del líder " + tipo + ":\u001B[0m"); // Verde
            System.out.print("\u001B[32mNombre:\u001B[0m ");
            nombre = scanner.nextLine();
            System.out.print("\u001B[32mApellido:\u001B[0m ");
            apellido = scanner.nextLine();
            System.out.print("\u001B[32mEdad:\u001B[0m ");
            edad = scanner.nextInt();
            System.out.print("\u001B[32mFuerza:\u001B[0m ");
            fuerza = scanner.nextInt();
            scanner.nextLine(); // Consumir el salto de línea
        }

        apellidosGuerreros.put(nombre, apellido);

        return tipo.equals("Griego") ? new Griego(nombre, edad, fuerza) : new Troyano(nombre, edad, fuerza);
    }

    private static List<Griego> generarEjercitoGriego(Guerrero lider, int cantidadSoldados) {
        List<Griego> ejercito = new ArrayList<>();
        ejercito.add(new Griego(lider, obtenerNombreAleatorio(nombresGriegos)));

        Random random = new Random();
        for (int i = 1; i < cantidadSoldados; i++) {
            Griego soldado = new Griego(obtenerNombreAleatorio(nombresGriegos),
                    15 + random.nextInt(46), 6 + random.nextInt(5));
            ejercito.add(soldado);
        }

        return ejercito;
    }

    private static List<Troyano> generarEjercitoTroyano(Guerrero lider, int cantidadSoldados) {
        List<Troyano> ejercito = new ArrayList<>();
        ejercito.add(new Troyano(lider, obtenerNombreAleatorio(nombresTroyanos)));

        Random random = new Random();
        for (int i = 1; i < cantidadSoldados; i++) {
            Troyano soldado = new Troyano(obtenerNombreAleatorio(nombresTroyanos),
                    15 + random.nextInt(46), 6 + random.nextInt(5));
            ejercito.add(soldado);
        }

        return ejercito;
    }

    private static String obtenerNombreAleatorio(Set<String> nombres) {
        List<String> nombresList = new ArrayList<>(nombres);
        Collections.shuffle(nombresList);
        return nombresList.get(0);
    }

    private static void mostrarEjercito(List<? extends Guerrero> ejercito) {
        for (Guerrero guerrero : ejercito) {
            String nombreCompleto = guerrero.getNombre();
            if (apellidosGuerreros.containsKey(nombreCompleto)) {
                nombreCompleto += " " + apellidosGuerreros.get(nombreCompleto);
            }
            System.out.println(nombreCompleto + " - Edad: " + guerrero.getEdad() +
                    ", Fuerza: " + guerrero.getFuerza());
        }
    }

    private static void realizarEnfrentamientos(List<Griego> ejercitoGriego, List<Troyano> ejercitoTroyano) {
        Random random = new Random();
        for (int i = 0; i < ejercitoGriego.size(); i++) {
            // Combate
     System.out.print("\u001B[35m"); // Morado
System.out.println("---------COMBATE #" + (i + 1) + "-----------");
System.out.print("\u001B[0m"); // Restaurar el color por defecto
System.out.println("Enfrentamiento entre " + ejercitoGriego.get(i).getNombre() + " y " + ejercitoTroyano.get(i).getNombre());

            // Ataque del Griego al Troyano
            int ataqueGriego = random.nextInt(10) + 1;
            String mensajeAtaqueGriego = obtenerMensajeBatalla(ejercitoGriego.get(i), ejercitoTroyano.get(i));
            System.out.println(mensajeAtaqueGriego + ", " + ataqueGriego + " de daño.");

            ejercitoTroyano.get(i).recibirAtaque(ataqueGriego);

            // Estado actual del Troyano
            System.out.println("Estado actual de " + ejercitoTroyano.get(i).getNombre() + ": " +
                    obtenerEstado(ejercitoTroyano.get(i)));

            // Contraataque del Troyano al Griego
            if (!ejercitoTroyano.get(i).isMuerto()) {
                int ataqueTroyano = random.nextInt(10) + 1;
                String mensajeContraataque = obtenerMensajeContraataque(ejercitoTroyano.get(i), ejercitoGriego.get(i));
                System.out.println(mensajeContraataque + ", " + ataqueTroyano + " de daño.");

                ejercitoGriego.get(i).recibirAtaque(ataqueTroyano);

                // Estado actual del Griego
                System.out.println("Estado actual de " + ejercitoGriego.get(i).getNombre() + ": " +
                        obtenerEstado(ejercitoGriego.get(i)));
            }

            System.out.println(); // Separador entre enfrentamientos
        }
    }

    private static String obtenerMensajeBatalla(Guerrero atacante, Guerrero defensor) {
        Random random = new Random();
        String mensaje = atacante.getNombre() + mensajesBatalla.get(random.nextInt(mensajesBatalla.size())) + defensor.getNombre();
        return mensaje;
    }

    private static String obtenerMensajeContraataque(Guerrero atacante, Guerrero defensor) {
        Random random = new Random();
        String mensaje = atacante.getNombre() + mensajesContraataque.get(random.nextInt(mensajesContraataque.size())) + defensor.getNombre();
        return mensaje;
    }

    private static String obtenerEstado(Guerrero guerrero) {
        if (guerrero.isMuerto()) {
            return "Muerto";
        } else if (guerrero.isHerido() && guerrero.retirarse()) {
            return "Herido/Retirado";
        } else if (guerrero.isHerido()) {
            return "Herido";
        } else {
            return "Vivo";
        }
    }

    private static void mostrarResultadosFinales(List<Griego> ejercitoGriego, List<Troyano> ejercitoTroyano) {
        System.out.println("---- Resultados Finales ----");

        int bajasTroyanos = contarBajas(ejercitoTroyano);
        int bajasGriegos = contarBajas(ejercitoGriego);

        System.out.println("Número de bajas troyanas: " + bajasTroyanos);
        System.out.println("Número de bajas griegas: " + bajasGriegos);

        if (bajasTroyanos > bajasGriegos) {
            System.out.println("Ganaron los troyanos");
        } else if (bajasGriegos > bajasTroyanos) {
            System.out.println("Ganaron los griegos");
        } else {
            System.out.println("La batalla terminó en empate");
        }

        int totalBajas = bajasTroyanos + bajasGriegos;
        System.out.println("Total de bajas: " + totalBajas);

        // Mostrar guerreros que quedaron vivos
        System.out.println("\nGuerreros que quedaron vivos:");

        for (Griego griego : ejercitoGriego) {
            if (!griego.isMuerto()) {
                System.out.println(griego.getNombre());
            }
        }

        for (Troyano troyano : ejercitoTroyano) {
            if (!troyano.isMuerto()) {
                System.out.println(troyano.getNombre());
            }
        }
    }

    private static int contarBajas(List<? extends Guerrero> ejercito) {
        int bajas = 0;
        for (Guerrero guerrero : ejercito) {
            if (guerrero.isMuerto()) {
                bajas++;
            }
        }
        return bajas;
    }
}
