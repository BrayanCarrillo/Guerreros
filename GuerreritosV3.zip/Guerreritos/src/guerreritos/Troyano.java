
package guerreritos;

class Troyano extends Guerrero {
    public Troyano(String nombre, int edad, int fuerza) {
        super(nombre, edad, fuerza);
    }

    public Troyano() {
        super();
    }

    public Troyano(Guerrero otroGuerrero, String nombre) {
        super(otroGuerrero, nombre);
    }

    Troyano(Guerrero lider, String obtenerNombreAleatorio, int i, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Troyano(String nombre, String apellido, int edad, int fuerza) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean retirarse() {
        return false; // Los troyanos no se pueden retirar
    }
}

