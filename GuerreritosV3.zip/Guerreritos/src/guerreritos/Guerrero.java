

package guerreritos;

import java.util.Random;

abstract class Guerrero {
    protected String nombre;
    protected int edad;
    protected int fuerza;
    protected boolean herido;
    protected boolean muerto;

    public Guerrero(String nombre, int edad, int fuerza) {
        this.nombre = nombre;
        this.edad = comprobarEdad(edad) ? edad : 25;
        this.fuerza = comprobarFuerza(fuerza) ? fuerza : 5;
        this.herido = false;
        this.muerto = false;
    }

    public Guerrero() {
        this.nombre = "GuerreroX";
        this.edad = 15;
        this.fuerza = 1;
        this.herido = false;
        this.muerto = false;
    }

    public Guerrero(Guerrero otroGuerrero, String nombre) {
        this.nombre = nombre;
        this.edad = otroGuerrero.edad;
        this.fuerza = otroGuerrero.fuerza;
        this.herido = otroGuerrero.herido;
        this.muerto = otroGuerrero.muerto;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getFuerza() {
        return fuerza;
    }

    public boolean isHerido() {
        return herido;
    }

    public boolean isMuerto() {
        return muerto;
    }

    public static boolean comprobarEdad(int edad) {
        return (edad >= 15 && edad <= 60);
    }

    public static boolean comprobarFuerza(int fuerza) {
        return (fuerza >= 1 && fuerza <= 10);
    }

    public abstract boolean retirarse();

    public void recibirAtaque(int ataque) {
        this.fuerza -= ataque;
        if (this.fuerza <= 0) {
            this.fuerza = 0;
            this.muerto = true;
        } else if (this.fuerza <= 4) {
            this.herido = true;
        }
    }
}